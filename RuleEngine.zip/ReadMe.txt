Assumtions :
 1. DataTime format in the Signal is same as Python DateTime format.
 2. It Incoming data stream is User Input and Two Signals separated by "}," 
 